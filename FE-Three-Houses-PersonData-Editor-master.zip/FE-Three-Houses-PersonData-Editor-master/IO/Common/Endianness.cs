﻿namespace ThreeHousesPersonDataEditor
{
    public enum Endianness
    {
        Little,
        Big
    }
}
