﻿namespace THAT
{
    public enum StringBinaryFormat
    {
        Unknown,
        NullTerminated,
        FixedLength,
        PrefixedLength8,
        PrefixedLength16,
        PrefixedLength32
    }
}
