﻿namespace THAT
{
    public enum Endianness
    {
        Little,
        Big
    }
}
