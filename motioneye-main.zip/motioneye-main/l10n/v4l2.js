/* fake file to allow translation of v4l2-ctl output */
/* non exhaustive list of possible controls */

i18n.gettext("Auto Exposure");
i18n.gettext("Backlight Compensation");
i18n.gettext("Brightness");
i18n.gettext("Contrast");
i18n.gettext("Exposure Absolute");
i18n.gettext("Exposure Auto");
i18n.gettext("Exposure Auto Priority");
i18n.gettext("Exposure Time Absolute");
i18n.gettext("Focus Absolute");
i18n.gettext("Focus Auto");
i18n.gettext("Gain");
i18n.gettext("Gamma");
i18n.gettext("Hue");
i18n.gettext("Led1 Mode");
i18n.gettext("Led1 Frequency");
i18n.gettext("Pan Absolute");
i18n.gettext("Power Line Frequency");
i18n.gettext("Saturation");
i18n.gettext("Sharpness");
i18n.gettext("Tilt Absolute");
i18n.gettext("White Balance Temperature");
i18n.gettext("White Balance Temperature Auto");
i18n.gettext("Zoom Absolute");
